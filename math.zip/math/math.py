def plus(a, b):
      return a + b

def minus(a, b):
      return a - b

def bagi(a, b):
      return a / b

def modulus(a, b):
      return a % b

def kali(a, b):
      return a * b
 
def pangkat(a, b):
      return a ** b

def floor(a, b):
      return a // b
